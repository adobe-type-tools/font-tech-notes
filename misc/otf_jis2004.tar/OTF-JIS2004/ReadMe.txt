Building JIS2004-Savvy OpenType Fonts
Dr. Ken Lunde, Adobe Systems Incorporated (lunde@adobe.com)
Dated 10/31/2007

1) Adobe-Japan1-3 Font Recommendations

Menu Names: Use "StdN" as the identifier, to distinguish JIS2004-savvy
  fonts from their JIS90-savvy versions that use the "Std" identifier.
  This identifier shall be used in the PostScript and menu names.

GSUB Features: Use the attached "aj13-gsub-jp04+144.txt" file for the
  GSUB features, to be used in the "features" file, if AFDKO tools are
  used.

Glyph Complement: Use all of Adobe-Japan1-3 (9,353 glyphs) plus 144
  additional CIDs from the Adobe-Japan1-4 through Adobe-Japan1-6
  regions, as shown below:

  Adobe-Japan1-3: CIDs 0-9353 (all)
  Adobe-Japan1-4: CIDs 9354, 9779, 12101, 12870, 13320-13327, 13330,
    13332-13333, 13335-13341, 13343, 13345-13355, 13358-13369, 13371,
    13373-13382, 13385-13388, 13391-13400, 13402, 13460, 13495, 13538,
    13624, 13650, 13673, 13731, 13803, 13860, 13893, 13915, 13949,
    13964, 14013, 14066, 14074, 14111, 14116, 14196, 14272 & 14290 (93)
  Adobe-Japan1-5: CIDs 16977, 17041, 18760, 19312, 19346, 20175,
    20222, 20263-20296, 20301-20305, 20307 & 20314 (48)
  Adobe-Japan1-6: CIDs 21072-21074 (3)

CFF: Because the glyph complement includes CIDs from the Adobe-Japan1-
  6 region, the 'CFF' table shall use "6" as the value for the
  CFF.supplement field, identifying the font as an Adobe-Japan1-6
  subset font.

2) Adobe-Japan1-5 Font Recommendations

Menu Names: Use "Pr5N" as the identifier, to distinguish JIS2004-savvy
  fonts from their JIS90-savvy versions that use the "Pr5" identifier.
  This identifier shall be used in the PostScript and menu names.

GSUB Features: Use the attached "aj15-gsub-jp04+8.txt" file for the
  GSUB features, to be used in the "features" file, if AFDKO tools are
  used.

Glyph Complement: Use all of Adobe-Japan1-5 (20,317 glyphs) plus eight
  additional CIDs from the Adobe-Japan1-6 region, as shown below:

  Adobe-Japan1-5: CIDs 0-20316 (all)
  Adobe-Japan1-6: CIDs 21072-21074, 21371, 21558, 21722, 21933 & 22920 (8)

CFF: Because the glyph complement includes CIDs from the Adobe-Japan1-
  6 region, the 'CFF' table shall use "6" as the value for the
  CFF.supplement field, identifying the font as an Adobe-Japan1-6
  subset font.

3) Adobe-Japan1-6 Font Recommendations

Menu Names: Use "Pr6N" as the identifier, to distinguish JIS2004-savvy
  fonts from their JIS90-savvy versions that use the "Pr6" identifier.
  This identifier shall be used in the PostScript and menu names.

GSUB Features: Use the attached "aj16-gsub-jp04.txt" file for the GSUB
  features, to be used in the "features" file, if AFDKO tools are
  used.

Glyph Complement: Use all of Adobe-Japan1-6 (23,058 glyphs) as shown
  below:

  CIDs 0-23057 (all)

4) CMap Files

Use the attached "UniJIS2004-UTF32-H" or "UniJISX02132004-UTF32-H"
CMap file to build the JIS2004-savvy 'cmap' tables. These CMap files
differ only in the mappings for sixty-five non-kanji code points,
whereby the former map to full-width glyphs, and the latter map to
proportional glyphs. Whichever CMap is used, you are strongly advised
to use the same CMap file consistently across your JIS2004-savvy font
products.

5) More Information

Please read the attached "JIS2004Encodings3.pdf" in its entirety.

That is all.
